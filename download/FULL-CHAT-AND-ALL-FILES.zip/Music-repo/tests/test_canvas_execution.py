"""Execute the real song-node chain on CPU with a stub pipeline.

The canvas regression that reached Kaggle (YuE2LoadEngine returned True while
downstream nodes read engine-module attributes) is impossible to see in
source-level tests. This suite imports the real node pack with stub ComfyUI
modules and executes Run Context -> Load Engine -> Style/Lyrics -> Plan Score
-> Song Tokens -> Acoustic Synthesis -> VAE Decode -> Save Song end to end.
"""
import dataclasses
import importlib
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from types import ModuleType, SimpleNamespace
from unittest.mock import patch

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

STUBBED = ("folder_paths", "comfy", "comfy.model_management", "server", "aiohttp")


def install_stub_modules():
    folder_paths = ModuleType("folder_paths")
    folder_paths.get_output_directory = lambda: str(Path(os.environ["YUE2_OUTPUT_ROOT"]).parent)
    comfy = ModuleType("comfy")
    model_management = ModuleType("comfy.model_management")
    class InterruptProcessingException(Exception):
        pass
    model_management.InterruptProcessingException = InterruptProcessingException
    model_management.throw_exception_if_processing_interrupted = lambda: None
    comfy.model_management = model_management
    server = ModuleType("server")
    class PromptServer:  # No `instance` attribute: the routes block stays idle.
        pass
    server.PromptServer = PromptServer
    aiohttp = ModuleType("aiohttp")
    aiohttp.web = SimpleNamespace(json_response=lambda *a, **k: "stub")
    saved = {name: sys.modules.get(name) for name in STUBBED}
    sys.modules.update({"folder_paths": folder_paths, "comfy": comfy,
                        "comfy.model_management": model_management,
                        "server": server, "aiohttp": aiohttp})
    return saved


@dataclasses.dataclass
class FakeGenerationConfig:
    ode_steps: int = 16
    ode_method: str = "euler"


class CanvasChainTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory(prefix="yue2-canvas-chain-")
        cls.root = Path(cls.temp.name)
        cls.outputs = cls.root / "runs"
        cls.outputs.mkdir()
        os.environ.update({"YUE2_SUPPORT_DIR": str(ROOT),
                           "YUE2_RUNTIME_ROOT": str(cls.root / "runtime"),
                           "YUE2_OUTPUT_ROOT": str(cls.outputs),
                           "YUE2_ENGINE_SCRIPT": str(ROOT / "native_yue2" / "engine.py")})
        cls.saved_stubs = install_stub_modules()
        cls.saved_native = {name: mod for name, mod in sys.modules.items()
                            if name.split(".")[0] in {"native_yue2", "kaggle_yue2"}}
        for name in list(sys.modules):
            if name.split(".")[0] in {"native_yue2", "kaggle_yue2"}:
                del sys.modules[name]
        cls.pack = importlib.import_module("native_yue2.comfy_pack")
        cls.engine = importlib.import_module("native_yue2.engine")

    @classmethod
    def tearDownClass(cls):
        try:
            cls.pack.release_engine()
        except Exception:
            pass
        for name in list(sys.modules):
            if name.split(".")[0] in {"native_yue2", "kaggle_yue2"} and name not in cls.saved_native:
                del sys.modules[name]
        for name, mod in cls.saved_native.items():
            if mod is not None:
                sys.modules[name] = mod
        for name, mod in cls.saved_stubs.items():
            if mod is None:
                sys.modules.pop(name, None)
            else:
                sys.modules[name] = mod
        for key in ("YUE2_SUPPORT_DIR", "YUE2_RUNTIME_ROOT", "YUE2_OUTPUT_ROOT", "YUE2_ENGINE_SCRIPT"):
            os.environ.pop(key, None)
        cls.temp.cleanup()

    def setUp(self):
        self.pack._STATE.update(lock=None, run=None)
        self.pack.STAGE_TIMES.clear()
        self.engine.pipe = None
        self.samples = 50  # 50 tokens -> exactly 2.0 s of audio at 25 tokens/s.
        rng = np.random.RandomState(7)
        self.fake_latents = (rng.randn(5, 64) * 0.01).astype(np.float32)
        t = np.arange(self.samples / 25 * 48000)
        wave = (np.sin(t / 20.0) * 0.2).astype(np.float32)
        self.fake_audio = np.stack([wave, wave], axis=1)
        fake = SimpleNamespace(
            runtime_sha256="f" * 64, backend="cpu", weights="fake.safetensors",
            generation_config=FakeGenerationConfig(), last_acoustic_ranges=[(0, self.samples)],
            plan=lambda **kwargs: self.make_plan(kwargs),
            generate_semantic=lambda plan, *, sampling=None, cancelled=None, on_token=None:
                SimpleNamespace(tokens=list(range(self.samples)), truncated=False,
                                timing={"execution": "stub"}),
            synthesize=lambda semantic, *, cancelled=None: self.fake_latents,
            decode=lambda latents, **kwargs: self.fake_audio,
        )
        self.fake = fake
        patches = [patch.object(self.engine, "pipe", None),
                   patch.object(self.engine, "initialize_pipeline", side_effect=self.load_fake),
                   patch("native_yue2.process.check_gpu_room", lambda *a, **k: {"stub": True})]
        for item in patches:
            item.start()
            self.addCleanup(item.stop)

    def load_fake(self):
        self.engine.pipe = self.fake

    def make_plan(self, kwargs):
        from yue2.pipeline import SongRequest, SymbolicPlan
        request = SongRequest(style=kwargs.get("style", "s"), lyrics=kwargs.get("lyrics", "l"),
                              cot=kwargs.get("cot", "off"), seed=kwargs.get("seed", 7),
                              abc=kwargs.get("abc"), cfg_scale=kwargs.get("cfg_scale", 1.0))
        return SymbolicPlan(request, None, [], list(range(10)))

    def result(self, output):
        return output["result"] if isinstance(output, dict) else output

    def test_engine_node_returns_the_engine_module(self):
        # The exact Kaggle regression: downstream nodes call engine._cancelled.
        (run,) = self.result(self.pack.YuE2RunContext().execute(11))
        (engine_out,) = self.result(self.pack.YuE2LoadEngine().execute(run, keep_loaded=True))
        self.assertIs(engine_out, self.engine)

    def test_full_song_chain_saves_masters_and_status(self):
        nodes = self.pack
        (run,) = self.result(nodes.YuE2RunContext().execute(7))
        (engine_out,) = self.result(nodes.YuE2LoadEngine().execute(run))
        (prompt,) = self.result(nodes.YuE2StyleLyrics().execute(
            "symphonic metal", "[Verse]\nla\n\n[Chorus]\nla\n"))
        (plan,) = self.result(nodes.YuE2PlanScore().execute(
            run, engine_out, prompt, "Direct to audio", 1.0))
        (tokens,) = self.result(nodes.YuE2SongTokens().execute(
            run, engine_out, prompt, "Up to 8 min", plan=plan))
        (latents,) = self.result(nodes.YuE2SynthesizeLatents().execute(run, tokens, 16, "euler"))
        (audio,) = self.result(nodes.YuE2DecodeAudio().execute(run, latents))
        saved = nodes.YuE2SaveSong().execute(run, tokens, audio)
        directory = run["directory"]
        for name in ("audio.wav", "audio.flac", "playback.wav", "status.json", "settings.json",
                     "semantic.npy", "latent.npy", "latent_manifest.json", "plan.json",
                     "planning.json", "prefix.npy"):
            self.assertTrue((directory / name).is_file(), f"missing {name}")
        status = json.loads((directory / "status.json").read_text())
        self.assertEqual(status["ending_reason"], "model_end_token")
        self.assertFalse(status["semantic_truncated"])
        self.assertTrue((directory.parent / (directory.name + ".zip")).is_file())
        # The reused-engine path must also hand over the module, not a flag.
        self.engine.pipe = self.fake
        (engine_again,) = self.result(nodes.YuE2LoadEngine().execute(
            {"directory": directory, "seed": 7, "notes": [], "settings": {}, "cover_source": None}))
        self.assertIs(engine_again, self.engine)

    def test_audio_length_is_checked_against_tokens(self):
        import torch
        nodes = self.pack
        (run,) = self.result(nodes.YuE2RunContext().execute(5))
        (engine_out,) = self.result(nodes.YuE2LoadEngine().execute(run))
        (prompt,) = self.result(nodes.YuE2StyleLyrics().execute("s", "[Verse]\nla\n"))
        (tokens,) = self.result(nodes.YuE2SongTokens().execute(run, engine_out, prompt, "Up to 8 min"))
        short = self.fake_audio[:-9600]  # 0.2 s short of the token-implied length
        with self.assertRaises(ValueError):
            nodes.YuE2SaveSong().execute(run, tokens, {
                "waveform": torch.from_numpy(short).T.contiguous().unsqueeze(0).float(),
                "sample_rate": 48000})


if __name__ == "__main__":
    unittest.main()
