"""CPU-only tests for the automatic Music Studio Dataset builder.

The Kaggle SDK, the runtime compilation and the 25 GB of model downloads are
replaced here; everything else is the real builder path, including the manifest,
the one-file-at-a-time upload loop, the receipts and the release of only owned
temporary downloads.
"""
import base64
import hashlib
import io
import json
import os
from pathlib import Path
import tempfile
import types
import unittest
import zipfile
from unittest.mock import patch

from music_studio import common, dataset
from music_studio import build_runtime, preflight as preflight_module

ROOT = Path(__file__).resolve().parents[2]


def digest_of(name):
    return hashlib.sha256(name.encode()).hexdigest()


class DatasetFlowTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.input_root = self.root / 'input'
        self.input_root.mkdir()
        self.receipt_dir = self.root / 'receipts'
        self.cache = self.root / 'cache'

    def record(self, name, size):
        return dict(name=name, path='models/' + name, bytes=size, sha256=digest_of(name),
                    source='https://example.invalid/' + name, role='test', license='test-only')

    def catalog(self, count=3):
        return dict(schema=1, profile=common.PROFILE,
                    assets=[self.record(f'asset-{n}.bin', 1024 * (n + 1)) for n in range(count)])

    def runtime(self):
        sources = json.loads((common.HERE / 'sources.json').read_text())
        return dict(name='music-studio-runtime.bundle', bytes=4096,
                    sha256=hashlib.sha256(b'runtime').hexdigest(), architecture='x86_64',
                    cuda_architectures=[75], build_mode='cuda',
                    source_fingerprint=common.fingerprint(sources),
                    compatibility={'libc': ['glibc', '2.35'], 'cuda': '13.0.2'})

    def fake_api(self):
        """The SDK call convention the builder patches: instance-level upload_files."""
        api = types.SimpleNamespace(config_values={'username': 'sanitized-owner'}, folders=[])

        def upload_files(folder, request, quiet=True, dir_mode='skip'):
            names = sorted(p.name for p in Path(folder).iterdir())
            request.files.extend(names)
            api.folders.append(names)

        def dataset_create_new(folder, public=False, quiet=False, convert_to_csv=False, dir_mode='skip'):
            api.metadata = json.loads((Path(folder) / 'dataset-metadata.json').read_text())
            api.public = public
            # The real SDK makes one upload_files call for the request; the builder
            # redirects that single call once per record it must send.
            request = types.SimpleNamespace(files=[])
            api.upload_files(folder=folder, request=request)
            api.request_files = request.files
            return {'status': 'ok'}

        api.upload_files = upload_files
        api.dataset_create_new = dataset_create_new
        return api

    def run_builder(self, catalog, api, owner=''):
        # These tests replace the SDK and the compiler; the remote probe
        # is exercised separately in PreflightTests.
        probe_patch = patch.object(dataset, 'preflight', return_value=True)
        probe_patch.start()
        self.addCleanup(probe_patch.stop)
        def build_runtime_record(scratch, jobs=2):
            scratch = Path(scratch)
            scratch.mkdir(parents=True, exist_ok=True)
            archive = scratch / 'music-studio-runtime.bundle'
            archive.write_bytes(b'runtime')
            (scratch / 'runtime-build.json').write_text(json.dumps(self.runtime()))
            for name in ('bundle', 'cargo', 'cuda'):
                (scratch / name).mkdir(exist_ok=True)
            return archive, self.runtime()

        def transfer(record, destination, reserve=0):
            destination = Path(destination)
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(b'x' * record['bytes'])
            return destination

        def copy_link(self_path, target, target_is_directory=False):
            # `folder/name` is only a handle for the SDK; copying keeps the same
            # one-file-at-a-time behaviour where symlinks would need privileges.
            Path(self_path).write_bytes(Path(target).read_bytes())

        printed = []
        with patch.object(dataset, 'authenticated_api', return_value=api), \
                patch.object(dataset, 'build_runtime_record', side_effect=build_runtime_record), \
                patch.object(dataset, 'transfer', side_effect=transfer), \
                patch.object(dataset, 'verify', side_effect=lambda path, record: path), \
                patch.object(dataset, 'validate_manifest', side_effect=lambda manifest: manifest), \
                patch.object(dataset, 'choose_scratch',
                             side_effect=lambda required, candidates, name, reserve=0: self.root / name), \
                patch.object(Path, 'symlink_to', copy_link), \
                patch('builtins.print', side_effect=lambda *a, **k: printed.append(' '.join(map(str, a)))):
            result = dataset.create_dataset(catalog, self.receipt_dir, self.input_root, self.cache,
                                            owner=owner, jobs=1, api=api)
        return result, '\n'.join(printed)

    def test_saved_catalog_is_validated(self):
        real = json.loads((common.HERE / 'catalog.json').read_text())
        dataset.validate_catalog(real)
        for mutate in (lambda c: c['assets'][0].__setitem__('sha256', 'not-a-digest'),
                       lambda c: c.__setitem__('assets', []),
                       lambda c: c.__setitem__('profile', 'other'),
                       lambda c: c['assets'][1].__setitem__('bytes', 'big'),
                       lambda c: c['assets'][2].__setitem__('name', 'nested/model.bin')):
            broken = json.loads(json.dumps(real))
            mutate(broken)
            with self.assertRaises(RuntimeError):
                dataset.validate_catalog(broken)

    def test_builder_streams_runtime_then_assets_then_manifest(self):
        catalog = self.catalog()
        api = self.fake_api()
        result, printed = self.run_builder(catalog, api)
        uploads = [name for folder in api.folders for name in folder]
        self.assertTrue(result['handle'].startswith('sanitized-owner/music-studio-dataset-v1-'))
        self.assertTrue(result['url'].startswith('https://www.kaggle.com/datasets/sanitized-owner/'))
        self.assertEqual(uploads[0], 'music-studio-runtime.bundle')
        self.assertEqual(uploads[-2:], ['MUSIC-STUDIO-NOTICES.md', 'music-studio-manifest.json'])
        self.assertEqual(len(uploads), len(catalog['assets']) + 3)
        receipt = json.loads((self.receipt_dir / 'dataset-upload.json').read_text())
        self.assertTrue(receipt['submitted'])
        self.assertTrue(receipt['requested_private'])
        self.assertFalse(api.public, 'the create request must be private')
        manifest = json.loads((self.receipt_dir / 'music-studio-manifest.json').read_text())
        self.assertEqual(len(manifest['files']), 3)
        self.assertEqual(manifest['model_bytes'], sum(r['bytes'] for r in catalog['assets']))
        self.assertIn('PRIVATE MUSIC STUDIO DATASET SUBMITTED', printed)
        self.assertTrue((self.receipt_dir / 'upload-progress.json').is_file())

    def test_owned_downloads_are_released_and_inputs_preserved(self):
        catalog = self.catalog(2)
        attached = self.input_root / 'dataset' / catalog['assets'][0]['name']
        attached.parent.mkdir(parents=True)
        attached.write_bytes(b'x' * catalog['assets'][0]['bytes'])
        api = self.fake_api()
        self.run_builder(catalog, api)
        self.assertTrue(attached.is_file(), 'an attached input must never be deleted')
        self.assertFalse((self.cache / catalog['assets'][1]['name']).exists(),
                         'this builder owns and releases its own downloaded cache file')

    def test_missing_owner_stops_before_any_work(self):
        api = types.SimpleNamespace(config_values={})
        with patch.object(dataset, 'build_runtime_record') as build, \
                patch.object(dataset, 'authenticated_api', return_value=api):
            with self.assertRaises(RuntimeError):
                dataset.create_dataset(self.catalog(), self.receipt_dir, self.input_root,
                                       self.cache, owner='', api=api)
        build.assert_not_called()


class CpuToolchainTests(unittest.TestCase):
    def test_cpu_helpers_cannot_inherit_cuda_toolkit_detection(self):
        common_options = [
            '-G', 'Ninja', '-DGGML_NATIVE=OFF', '-DGGML_CUDA=ON',
            '-DCMAKE_CUDA_ARCHITECTURES=75-real',
            '-DCMAKE_CUDA_COMPILER=/tmp/cuda/bin/nvcc',
            '-DCUDAToolkit_ROOT=/tmp/cuda',
            '-DCMAKE_EXE_LINKER_FLAGS=-Wl,-rpath-link,/tmp/cuda/lib',
        ]
        cpu = build_runtime.cpu_cmake_options(common_options)
        self.assertIn('-DGGML_CUDA=OFF', cpu)
        self.assertIn('-DCMAKE_DISABLE_FIND_PACKAGE_CUDAToolkit=TRUE', cpu)
        self.assertFalse(any(option.startswith(('-DCMAKE_CUDA', '-DCUDAToolkit_ROOT=',
                                               '-DCMAKE_EXE_LINKER_FLAGS=')) for option in cpu))
        # The separate CUDA trainer keeps the normal options untouched.
        self.assertIn('-DGGML_CUDA=ON', common_options)
        self.assertIn('-DCMAKE_CUDA_COMPILER=/tmp/cuda/bin/nvcc', common_options)


class CudaExtractionTests(unittest.TestCase):
    def test_tar_extraction_preserves_executable_bit(self):
        import io
        import tarfile
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            archive_path = Path(tmp) / 'fixture.tar'
            data = b'cuda compiler fixture'
            with tarfile.open(archive_path, 'w') as tar:
                info = tarfile.TarInfo('cuda/bin/nvcc')
                info.mode, info.size = 0o755, len(data)
                tar.addfile(info, io.BytesIO(data))
            with tarfile.open(archive_path) as source:
                target = build_runtime.write_tar_file(source, source.getmember('cuda/bin/nvcc'), Path(tmp) / 'out/bin/nvcc')
            self.assertEqual(target.read_bytes(), data)
            if os.name != 'nt':
                self.assertTrue(target.stat().st_mode & 0o111)

    def test_static_cuda_runtime_is_kept_but_heavy_static_blas_is_not(self):
        for name in ('lib/libcudart_static.a', 'lib/libcudadevrt.a', 'lib/libculibos.a', 'bin/nvcc'):
            self.assertTrue(build_runtime.toolkit_member_needed(Path(name), 2 * 1024 * 1024), name)
        for name in ('lib/libcublas_static.a', 'lib/libcublasLt_static.a', 'lib/libcufft_static.a'):
            self.assertFalse(build_runtime.toolkit_member_needed(Path(name), 900 * 1024 * 1024), name)
        self.assertFalse(build_runtime.toolkit_member_needed(Path('lib/libsomething.a'), 900 * 1024 * 1024))
        self.assertTrue(build_runtime.toolkit_member_needed(Path('lib/libsomething.a'), 1024))

    def test_cuda_probe_rejects_missing_compiler(self):
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaisesRegex(RuntimeError, 'missing nvcc'):
                build_runtime.validate_cuda_compiler(Path(tmp) / 'cuda', {}, tmp)

    def test_cuda_probe_writes_a_real_newline_in_cuda_source(self):
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            cuda = work / 'cuda'
            compiler = cuda / 'bin/nvcc'
            compiler.parent.mkdir(parents=True)
            compiler.write_text('fixture')
            host = work / 'c++'
            host.write_text('fixture')
            output = work / 'cuda-compiler-probe/probe.o'

            compiled = []
            linked = []

            def run(command, **kwargs):
                if command[1] == '--version':
                    return types.SimpleNamespace(returncode=0, stdout='nvcc fixture')
                if '-c' in command:
                    source = Path(command[command.index('-c') + 1])
                    compiled.append(source.read_bytes().replace(b'\r\n', b'\n'))
                    Path(command[command.index('-o') + 1]).write_bytes(b'object')
                    return types.SimpleNamespace(returncode=0, stdout='')
                linked.append(1)
                Path(command[command.index('-o') + 1]).write_bytes(b'binary')
                return types.SimpleNamespace(returncode=0, stdout='')

            with patch.object(build_runtime.os, 'access', return_value=True), \
                    patch.object(build_runtime.shutil, 'which', return_value=str(host)), \
                    patch.object(build_runtime.subprocess, 'run', side_effect=run):
                build_runtime.validate_cuda_compiler(cuda, {}, work)
            self.assertEqual(output.read_bytes(), b'object')
            self.assertEqual(compiled, [b'extern "C" __global__ void music_studio_cuda_probe() {}\n'])
            # The probe must link too: compiling alone hides missing static runtime libraries.
            self.assertEqual(linked, [1])
            self.assertEqual((work / 'cuda-compiler-probe/probe').read_bytes(), b'binary')


class ToolkitEnvTests(unittest.TestCase):
    def test_toolkit_still_exports_cuda_env_when_already_complete(self):
        """A completed toolkit download must not skip the compiler environment."""
        import tempfile
        from music_studio.common import fingerprint
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            cuda = work / 'cuda'
            cuda.mkdir()
            sources = dict(runtime_assets=[
                dict(id='cuda_nvcc', name='nvcc.tar.xz', source='https://example.invalid/nvcc',
                     sha256='0' * 64, bytes=1),
                dict(id='cuda_cudart', name='cudart.tar.xz', source='https://example.invalid/cudart',
                     sha256='2' * 64, bytes=1),
                dict(id='libcublas', name='cublas.tar.xz', source='https://example.invalid/cublas',
                     sha256='1' * 64, bytes=1),
            ])
            selected = [r for r in sources['runtime_assets']
                        if r['id'].startswith('cuda_') or r['id'] in ('libcublas', 'libnvvm')]
            (cuda / 'bin').mkdir()
            for name in ('nvcc', 'ptxas', 'cudafe++'):
                # The builder only trusts a cache whose compilers kept their
                # executable mode from the pinned archives.
                (cuda / 'bin' / name).write_text('fixture')
                os.chmod(cuda / 'bin' / name, 0o755)
            (cuda / 'lib').mkdir()
            for name in ('libcudart_static.a', 'libcudadevrt.a', 'libcudart.so.13'):
                (cuda / 'lib' / name).write_text('fixture')
            for record in selected:
                (cuda / ('.asset-' + record['id'])).write_text(record['sha256'])
            (cuda / '.complete').write_text(fingerprint(selected))
            env = dict(os.environ)
            with patch.object(build_runtime, 'transfer') as transfer, patch.object(build_runtime, 'validate_cuda_compiler'):
                build_runtime.toolkit(work, sources, env)
            transfer.assert_not_called()
            self.assertEqual(env['CUDACXX'], str(cuda / 'bin/nvcc'))
            self.assertEqual(env['CUDAToolkit_ROOT'], str(cuda))
            self.assertEqual(env['CUDA_PATH'], str(cuda))
            self.assertTrue(str(cuda / 'bin') in env['PATH'].split(os.pathsep))


    def test_toolkit_refetches_cudart_when_static_runtime_files_are_missing(self):
        import io
        import tarfile
        import tempfile
        from music_studio.common import fingerprint
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            cuda = work / 'cuda'
            (cuda / 'bin').mkdir(parents=True)
            for name in ('nvcc', 'ptxas', 'cudafe++'):
                (cuda / 'bin' / name).write_text('fixture')
                os.chmod(cuda / 'bin' / name, 0o755)
            sources = dict(runtime_assets=[
                dict(id='cuda_nvcc', name='nvcc.tar.xz', source='https://example.invalid/nvcc',
                     sha256='0' * 64, bytes=1),
                dict(id='cuda_cudart', name='cudart.tar.xz', source='https://example.invalid/cudart',
                     sha256='2' * 64, bytes=1),
            ])
            selected = sources['runtime_assets']
            for record in selected:
                (cuda / ('.asset-' + record['id'])).write_text(record['sha256'])
            (cuda / '.complete').write_text(fingerprint(selected))

            def fresh_archive(record, destination):
                # The builder deletes each archive it consumes, so every
                # transfer call must deliver its own unread copy.
                path = Path(destination)
                with tarfile.open(path, 'w:xz') as tar:
                    for name in ('lib/libcudart_static.a', 'lib/libcudadevrt.a'):
                        data = b'cudart fixture'
                        member = tarfile.TarInfo('cuda/' + name)
                        member.mode, member.size = 0o644, len(data)
                        tar.addfile(member, io.BytesIO(data))
                return path

            env = dict(os.environ)
            with patch.object(build_runtime, 'transfer', side_effect=fresh_archive) as transfer, \
                    patch.object(build_runtime, 'validate_cuda_compiler'):
                build_runtime.toolkit(work, sources, env)
            self.assertEqual([call.args[0]['id'] for call in transfer.call_args_list], ['cuda_cudart'],
                             'only the archive owning the missing runtime libraries is fetched again')
            for name in ('libcudart_static.a', 'libcudadevrt.a'):
                self.assertEqual((cuda / 'lib' / name).read_bytes(), b'cudart fixture')


class PreflightTests(unittest.TestCase):
    def record(self, name, size):
        return dict(name=name, source='https://example.invalid/' + name, bytes=size, kind='model')

    def test_dead_pin_stops_before_any_build(self):
        records = [self.record('good.bin', 10), self.record('gone.bin', 10)]

        def fake_probe(url, timeout=30):
            return ('ok', 10) if url.endswith('good.bin') else ('unreachable', 404)

        with patch.object(preflight_module, 'probe', side_effect=fake_probe),                 patch('builtins.print'):
            with self.assertRaises(RuntimeError) as caught:
                preflight_module.preflight(records)
        message = str(caught.exception)
        self.assertIn('gone.bin', message)
        self.assertIn('404', message)
        self.assertNotIn('good.bin', message)

    def test_size_mismatch_is_reported(self):
        with patch.object(preflight_module, 'probe', return_value=('ok', 99)), patch('builtins.print'):
            with self.assertRaises(RuntimeError) as caught:
                preflight_module.preflight([self.record('model.bin', 10)])
        self.assertIn('99 bytes, pinned 10', str(caught.exception))

    def test_all_good_pins_pass(self):
        with patch.object(preflight_module, 'probe', return_value=('ok', 10)), patch('builtins.print'):
            self.assertTrue(preflight_module.preflight([self.record('a.bin', 10)]))

    def test_every_pinned_remote_is_enumerated(self):
        real = json.loads((ROOT / 'music_studio/catalog.json').read_text())
        sources = json.loads((ROOT / 'music_studio/sources.json').read_text())
        records = preflight_module.remote_records(real, sources)
        self.assertEqual(sum(1 for r in records if r['kind'] == 'model'), len(real['assets']))
        self.assertGreater(sum(1 for r in records if r['kind'] == 'toolchain'), 8)
        self.assertTrue(all(r['source'].startswith('https://') for r in records))


class NotebookPayloadTests(unittest.TestCase):
    def test_driver_embeds_a_verified_builder_archive(self):
        notebook = json.loads((ROOT / 'Music-Studio-Dataset.ipynb').read_text())
        self.assertEqual(len(notebook['cells']), 2)
        code_cell = notebook['cells'][1]
        self.assertEqual(code_cell['cell_type'], 'code')
        self.assertEqual(code_cell['outputs'], [])
        self.assertEqual(notebook['metadata']['kaggle']['accelerator'], 'none')
        self.assertFalse(notebook['metadata']['kaggle']['isGpuEnabled'])
        code = ''.join(code_cell['source'])
        compile(code, 'Music-Studio-Dataset.ipynb', 'exec')
        encoded = code.split("base64.b64decode(", 2)[1].split(')')[0].strip().strip("'")
        payload = base64.b64decode(encoded)
        self.assertIn(hashlib.sha256(payload).hexdigest(), code)
        markdown = ''.join(notebook['cells'][0]['source'])
        catalog = json.loads((ROOT / 'music_studio/catalog.json').read_text())
        self.assertEqual(len(catalog['assets']), 18)
        for record in catalog['assets']:
            self.assertIn('`' + record['name'] + '`', markdown)
        self.assertIn('Accelerator None', markdown)
        self.assertIn('still compiles', markdown)
        self.assertIn('does not make', markdown)
        with zipfile.ZipFile(io.BytesIO(payload)) as archive:
            names = set(archive.namelist())
        expected = {'music_studio/' + name for name in
                    ('__init__.py', 'common.py', 'dataset.py', 'build_runtime.py', 'preflight.py', 'patches.py',
                     'launch.py', 'kaggle_upload.rs', 'upload.html', 'catalog.json',
                     'sources.json', 'NOTICES.md')}
        self.assertEqual(names, expected)
        with zipfile.ZipFile(io.BytesIO(payload)) as archive:
            embedded = {name.rsplit('/', 1)[-1]: archive.read(name) for name in archive.namelist()}
        dataset_source = embedded['dataset.py'].decode()
        runtime_source = embedded['build_runtime.py'].decode()
        self.assertIn('build_runtime_record(scratch, jobs)', dataset_source)
        self.assertIn('music-studio-runtime.bundle', runtime_source)
        self.assertIn('CMAKE_CUDA_ARCHITECTURES', runtime_source)
        sources = json.loads(embedded['sources.json'])
        for name, expected_digest in sources['patches'].items():
            self.assertEqual(hashlib.sha256(embedded[name]).hexdigest(), expected_digest,
                             name + ' must match the checksum pinned in the embedded sources.json')


if __name__ == '__main__':
    unittest.main()
