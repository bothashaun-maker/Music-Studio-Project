# 🎛️ Song Timestamp Studio — READ ME FIRST

**What this is:** an app that turns a song + the lyrics you already wrote into every
timestamp a music video needs — synced lyrics (LRC/SRT/VTT), YouTube chapters, REAPER
markers, a beat grid, and a beat-snapped Cut Plan (clip slots in seconds AND frames).

It runs as a **Kaggle notebook** (same pattern as your YuE2 / H3 notebooks) and opens
as a web app through a ☁️ **Cloudflare link** (`…trycloudflare.com`) with a 🟣 Gradio
backup link (`…gradio.live`). It works on **CPU** — no GPU hours burned — and on **any
song**, not just YuE2 renders.

## One-time install (5 minutes)

1. Unzip this folder. You need one file: `song-timestamp-studio.ipynb`.
2. Go to **kaggle.com** → **Create** → **New Notebook** (empty one).
3. **File → Import Notebook** → upload `song-timestamp-studio.ipynb`.
4. Settings (right panel):
   - **Internet → ON** (needed once, to download the Whisper model).
   - **Accelerator → None** is fine (CPU works; a T4 makes it faster if you want).
5. Press **Run All** (or run the two code cells top to bottom).

## Every song (2 minutes)

1. Wait for the links: the launch cell prints a ☁️ **Cloudflare** link
   (`https://xxxx.trycloudflare.com`) and a 🟣 Gradio backup (`https://xxxx.gradio.live`)
   — click **either** one.
2. In the app:
   - **1 · Load your song** — upload the WAV/MP3 (the WAV from your YuE2 run ZIP works).
   - **2 · Paste your lyrics** — one line per row, exactly as sung. Keep your
     `[Verse 1]` / `[Chorus]` tags: they become YouTube chapters + REAPER regions.
     *Leave the box empty to auto-transcribe instead (text = what the AI hears).*
   - Press **⚡ Get timestamps** (first run downloads the model, ~150 MB).
3. Check the confidence line: 🟢 75%+ is solid. 🔴 → turn **Vocal isolation ON** and/or
   model **small**, run again.
4. Copy any tab, or grab the **📦 Download all formats (.zip)** button.

## Trusting the numbers (your REAPER call)

- The app grades itself: it tells you what % of your lyric words it found in the audio, and the
  **Preview table grades every line** (`100% — solid`, `86% — solid`, `54% — check`, …).
- **▶️ Audition line #** plays from ~1.5 s before any line — quick ear check.
- **REAPER audit:** drop the WAV on a REAPER timeline, open the **Region/Marker Manager**
  (View → Region/Marker Manager) and drag the `_reaper_markers.csv` into it (REAPER 7.66+
  takes it natively — hold Shift to merge; older versions: install the free ReaPack script
  *X-Raym: Import items or markers or regions from CSV*). Lyrics = markers, sections =
  regions. Eyeball against the waveform — you make the call.
- Everything feels 0.3 s early? Type `0.3` in the **Nudge** box → Apply → re-download.

## Verified before shipping

Built on a synthetic song with known ground-truth timings (vocals placed at exact
seconds over a 98.7 BPM instrumental). Measured on CPU with the `base` model:

| Lyric line | True start | App result | Error |
|---|---|---|---|
| Walking through the city lights at midnight | 6.00 s | 5.78 s | −0.22 s |
| Neon shadows falling on the street | 13.50 s | 13.78 s | +0.28 s |
| I can hear the distant engines humming | 21.00 s | 21.34 s | +0.34 s |
| Feel the rhythm moving through my feet | 28.50 s | 28.96 s | +0.46 s |
| We are the dreamers in the night | 38.00 s | 38.33 s | +0.33 s |
| Holding on until the morning light | 45.50 s | 45.50 s | ±0.00 s |

All lines within **±0.46 s**, mean +0.20 s, 95% of lyric words located. Beat detection
found 98.7 BPM (true 100). The full engine test suite (37 checks: alignment accuracy,
chapters, beats, cut-plan math, every output format, nudge, auto-transcribe) passes, the
Gradio UI was driven in a real browser (upload → lyrics → run → all output tabs verified),
and the **Cloudflare tunnel was opened live** and served the app through a real
`…trycloudflare.com` URL. **Not yet verified on a real YuE2 render with sung vocals —
expect a bit more wobble than clean test speech; the REAPER audit is there for exactly that.**

## Honest limits

- Timing is **line-level** (great for lyric videos, captions, chapters, cut plans).
  Word-level karaoke highlighting is not included in v1.
- Chapters come from your own `[tags]` + where vocals start — the app does not pretend
  to "hear" that something is a chorus like Moises does.
- Beat detection can miss on unusual rhythms; the Cut Plan then falls back to even slots.
- Both links (Cloudflare + Gradio backup) live only while the Kaggle session runs.
